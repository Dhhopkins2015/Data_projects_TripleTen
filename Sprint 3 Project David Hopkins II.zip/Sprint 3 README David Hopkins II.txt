# 📊 Customer Returns & Profitability Analysis (Superstore Dataset)

**Author:** David Hopkins II  
**Tools Used:** Tableau, Excel  
**Focus Areas:** Profitability Optimization, Return Rate Analysis, Inventory Strategy

---

## 🧠 Project Overview

This project analyzes sales and return data from a sample Superstore dataset to uncover profit drivers, high-return products, and regional sales trends. It uses data visualization to provide actionable insights for improving profitability, streamlining inventory, and informing targeted marketing strategies.

The dashboard can be viewed here:  
👉 [**Interactive Tableau Dashboard**](https://public.tableau.com/views/Sprint4ProjectDavidHopkinsII/CustomersWithMostReturns)

---

## 🎯 Objectives

- Identify products and regions impacting profitability the most.
- Detect customers and items with high return rates.
- Uncover seasonal and geographic patterns in revenue.
- Recommend operational strategies based on data-driven insights.

---

## 📌 Key Insights

- **Top Profit Centers:** Copiers in the West and Chairs in the East.
- **Biggest Loss Categories:** Binders in Central and Tables in the East.
- **Return Trends:** Binders and Chairs dominate returns; certain fasteners may be misrepresented or faulty.
- **Customer Behavior:** A small group of customers are outliers in return frequency.
- **Ad Spend Recommendations:** Focus ad spend on New York, California, and Washington during high-performing months (Sept, Dec, Mar).
- **Profitability by Sub-Category:** Copiers, Phones, and Accessories show highest margins, while Tables and Bookcases are consistently unprofitable.
- **Return Rate by State:** Utah has the highest return rate at 0.5684, followed by California and Oregon.

---

## 🔧 Methodology

- Cleaned and transformed raw Superstore dataset using Excel.
- Built multiple Tableau dashboards to visualize sales, returns, customer behavior, and product performance.
- Cross-referenced return data with profitability to identify products to discontinue or reevaluate.
- Incorporated average return rates to support marketing and logistics decisions.

---

## 📈 Visuals & Features

- **Heatmaps** for regional profitability.
- **Bar charts** ranking top-returned items and customers.
- **Dual-axis graphs** comparing return rates vs. profit per sub-category.
- **Time-series charts** for identifying seasonal spikes in sales.

---

## ✅ Impact & Takeaways

This analysis demonstrates the value of combining return data and profit margins to inform smarter inventory and marketing strategies. By eliminating underperforming products and focusing on key profit drivers, the business can potentially increase margins and reduce waste—critical for long-term operational success.

---

## 🗂️ Files & Access

- 🔗 [Live Tableau Dashboard](https://public.tableau.com/views/Sprint4ProjectDavidHopkinsII/CustomersWithMostReturns)
- 📄 [Google Spreadsheet Source](https://docs.google.com/spreadsheets/d/15eC5rljGn-54cb3hi7_lArlIeTpx5uiN0g8nKmN76kc/edit#gid=868644233)

---

## 📬 Contact

**David Hopkins II**  
📧 [d.hopkins426@hotmail.com](mailto:d.hopkins426@hotmail.com)  
🔗 [LinkedIn](https://www.linkedin.com/in/YOUR-USERNAME)  
🌐 [GitHub](https://github.com/Dhhopkins2015)

---
