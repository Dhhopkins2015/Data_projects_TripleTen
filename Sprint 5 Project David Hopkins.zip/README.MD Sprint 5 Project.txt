Sprint 5 Project David Hopkins II

Sample.Superstore Data was analyzed to determine Product Return Rate by Left Joining the Return table to the Orders Table and creating a calculated field. This was compared against other dimensions and measures to provide insights and offer next steps as outlined in the Tableu Story

[View Dashboard]  (https://public.tableau.com/views/DavidHopkinsSprint5Project/CompletedStory?:language=en-US&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link)

[View Presentation] (https://drive.google.com/file/d/1JecOg6ZXCoDj5HFHOCvY2ZITfL28oZql/view?usp=sharing)