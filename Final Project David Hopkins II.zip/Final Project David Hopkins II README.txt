Final Project David Hopkins II

Restaurant and Order Tables were inner joined by Restaurant ID to gather insights on possible drivers of restaurant popularity and sales volume

[View Dashboard] (https://public.tableau.com/app/profile/david.hopkins.ii/viz/DavidHopkinsFinalProjectVisualsandDashboard/SalesDashboard?publish=yes) 

Write ups for Visuals / Report :

"SUM of Sales by Restaurant" -

Domino's Pizza is the clear leader among individual restaurants despite western food being ranked 5/9 out of cuisine cohorts. This suggests that large American companies have a brand name advantage, and Zomato should take steps to keep this account and dissuade Domino's from recruiting their own drivers

"SUM of Sales QTY by Rating Count" -  

"Too Few Ratings" accounts for over half of the Sales QTY , showing that new and infrequently reviewed restaurants like smaller non franchise locations are competitive in this market

"SUM of Sales by Restaurant Rating" - 

The overwhelming majority of sales occur in restaurants that have a review between 3.5 and 4.5 stars, with a sharper drop off towards the higher end of the scale than the lower, showing that perhaps customers believe too high of a rating is fraudulent. 

"SUM of Sales by Restaurant Cohort"-

Indian food is the clear winner amongst the cuisines offered, making almost four times the next closest cohort. Marketing towards owners of these establishments to make sure they work with Zomato may be a prudent move

"SUM of Sales by Cost Cohort"-

Almost all sales generated came from items priced 101-500 Rupees, which indicates that higher end options may be worth dropping from the Zomato Service



| INR Cohort   | USD Equivalent (approx.) |
| ------------ | ------------------------ |
| ₹0 – ₹100    | \$0 – \$1.20             |
| ₹101 – ₹500  | \$1.21 – \$6.00          |
| ₹501 – ₹1000 | \$6.01 – \$12.00         |
| ₹1000+       | \$12.01+                 |



Zomato has many exciting opporunities to further their interests in Restaurant Aggregation and Order Delivery

Indian Food is the most popular Cuisine and marketing towards owners of these establisments and suggesting them to users is likely to be profitable. 

While Fast Food / American were not the most popular Cuisines, individual restaurants such as Domino's, Pizza Hut and Subway are obvious outliers. It would be a good idea to work with any popular American chain closely, and work to establish Zomato as their primary delivery mode over their own drivers

Ratings dont matter as much as one would anticipate, with less reviewed restaurants and those rated 3.5-4.5 stars performing the best. The insight to gather is that people like trying new things and are skeptical of a score deemed "too high"

Menu items priced 101-500 Rupees comprise the majority of sales, when choosing restaurants to add or remove from service, being within those paramaters is a major benchmark to strive for

