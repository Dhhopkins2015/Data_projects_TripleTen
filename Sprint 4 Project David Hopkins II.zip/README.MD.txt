Sprint 4 Project David Hopkins II

Sample.Superstore Data was analyzed to determine which measures were impacting profitability and identify opportunities to maximize profit and efficiency 

[View Dashboard]  (https://public.tableau.com/views/Sprint4ProjectDavidHopkinsII/CustomersWithMostReturns?:language=en-US&publish=yes&:sid=&:redirect=auth&:display_count=n&:origin=viz_share_link)

Write Ups for Visuals:

Sub-Category/ Region
	
	The top two biggest profit centers were Copiers in the West and Chairs in the East
	The top two biggest loss centers were Binders in Central and Tables in the East

Products to Discontinue

	The bottom ten profitable items are displayed on a bar graph displaying just how much the store loses by selling these items

Profit by Sub-Category
	
	The top earning 3 sub-categories were copiers, phones, and accessories; The high profit margins indicate that focusing efforts on these subcategories have the highest potential for profitability. The bottom earning 3 sub-categories were tables, bookcases, and supplies; the fact that they cost the store money to sell suggests that they may not be worth keeping unless used as a loss leader.

Top 3 States / Months for Ads

	The top 3 states for profitability were New York, California, and Washington. The top 3 Months were September, December, and March. Advertising during the peak season in the busiest areas is ideal for optimizing the other insights gathered in this report. The suggested maximum budget for these campaigns is determined as 20% of the profit

Top 20 Most Returned Items

	The top 20 returned items are displayed in a bar chart, which shows that binders and chairs make up a large portion of the stores returns, along with an outlier product in the fastener sub-category which may point to an issue with the products description

Which States Returned Items Most

	The top 5 states with returns were Utah, California, Oregon, Tennessee, Colorado . Customers in these states were most likely to return items with Utah having the highest return rate at 0.5684

Customers With Most Returns

	The top ten customers are listed in order of most returns, these customers are outliers and require further investigation

Average Profit / Return Rate by Sub-Category

	The average profit and return rate shown side by side tell us that there is not much of a variation in the return rate, however copiers are extremely profitable and should be focused on in future promotions, while tables gross a negative profit and may not be worth carrying in the stores 